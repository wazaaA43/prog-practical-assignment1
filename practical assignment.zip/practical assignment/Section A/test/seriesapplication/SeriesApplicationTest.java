/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.seriesapplication;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */

public class SeriesApplicationTest {    

   private SeriesApplication app;

    @BeforeEach
    void setUp() {
        app = new SeriesApplication();
        app.addSeries(new SeriesModel("S001", "Breaking Code", 16, 10));
        app.addSeries(new SeriesModel("S002", "Java Hunters", 13, 8));
    }

    @Test
    void TestSearchSeries() {
        SeriesModel found = app.findSeriesById("S001");
        assertNotNull(found, "Series S001 should be found");
        assertEquals("Breaking Code", found.getSeriesName());
    }

    @Test
    void TestSearchSeries_SeriesNotFound() {
        SeriesModel found = app.findSeriesById("S999");
        assertNull(found, "Series S999 should NOT exist");
    }

    @Test
    void TestUpdateSeries() {
        boolean updated = app.updateSeriesById("S001", "Breaking Java", 18, 12);
        assertTrue(updated, "Update should succeed");

        SeriesModel updatedSeries = app.findSeriesById("S001");
        assertEquals("Breaking Java", updatedSeries.getSeriesName());
        assertEquals(18, updatedSeries.getSeriesAge());
        assertEquals(12, updatedSeries.getSeriesNumberOfEpisodes());
    }

    @Test
    void TestDeleteSeries() {
        boolean deleted = app.deleteSeriesById("S002");
        assertTrue(deleted, "Series S002 should be deleted");

        SeriesModel shouldBeGone = app.findSeriesById("S002");
        assertNull(shouldBeGone, "Series S002 should not exist anymore");
    }

    @Test
    void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = app.deleteSeriesById("S999");
        assertFalse(deleted, "Deleting S999 should fail since it does not exist");
    }

    @Test
    void TestSeriesAgeRestriction_AgeValid() {
        assertTrue(app.isValidAgeRestriction(9), "Age 9 should be valid");
        assertTrue(app.isValidAgeRestriction(18), "Age 18 should be valid");
    }

    @Test
    void TestSeriesAgeRestriction_SeriesAgeInValid() {
        assertFalse(app.isValidAgeRestriction(-5), "Age -5 should be invalid");
        assertFalse(app.isValidAgeRestriction(21), "Age 21 should be invalid");
    }

}
