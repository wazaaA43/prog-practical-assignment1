/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.seriesapplication;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class SeriesApplication {

    private Scanner scan = new Scanner(System.in);
    private ArrayList<SeriesModel> seriesList = new ArrayList<>();
    
    public static void main(String[] args) {
        SeriesApplication app = new SeriesApplication();
        app.launchMenu();
    }
    
    private void launchMenu() {
         
        while (true) {
            System.out.println("\nLATEST SERIES - 2025");
            System.out.println("*********************************");
            System.out.println("Enter (1) to launch menu or any other key to exist");

            String input = scan.nextLine();

            if (input.equals("1")) {
                showMenu(); //show the menu if user enters 1
            } else {
                System.out.println("Exiting program. Goodbye!");
                break; //Exist the loop and stop the program
            }
        }
            
    }
    
    private void showMenu() {
        
        while (true) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series.");
            System.out.println("(2) Search for a series.");
            System.out.println("(3) Update series.");
            System.out.println("(4) Delete a series.");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application.");
            System.out.print("Enter choice: ");
            String choice = scan.nextLine();
            
            switch (choice) {
                case "1":
                    captureSeries();
                    break;
                case "2":
                    searchSeries();
                    break;
                case "3":
                    updateSeries();
                    break;
                case "4":
                    deleteSeries();
                    break;
                case "5":
                    SeriesReport();
                    break;
                case "6":
                    ExitSeriesApplication();
                    return; // stop the menu loop
                default:
                    System.out.println("Invalid option. Please try again.");   
            }           
        }
    }
    
    // reusable validation method
    private int getValidatedAge() {
        int age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            if (scan.hasNextInt()) {
                age = scan.nextInt();
                scan.nextLine(); // Consume the newline character
                if (age >= 2 && age <= 18) {
                    return age; // Return the valid age and exit the loop
                } else {
                    System.out.println("You have entered an incorrect series age!!!");
                    System.out.println("Please re-enter the series age >> ");
                }
            } else {
                scan.nextLine(); // Clear the invalid input
                System.out.println("You have entered an incorrect series age!!!");
                System.out.println("Please re-enter the series age >> ");
            }
        }
    }
    
    public void captureSeries() {
        System.out.println("\nCAPTURE A NEW SERIES");
        System.out.println("***********************************");
        
        System.out.println("Enter the series id: ");
        String id = scan.nextLine();
        
        System.out.println("Enter the series name: ");
        String name = scan.nextLine();
        
        int age = getValidatedAge(); // Call the reusable method       

        System.out.print("Enter the number of episodes for " + name + ": ");
        int numEpisodes = scan.nextInt();
        scan.nextLine();

        // Save the series
        seriesList.add(new SeriesModel(id, name, age, numEpisodes));

        // Confirmation
        System.out.println("Series processed successfully!!!");
       
    }
    
    public void searchSeries() {

        System.out.println("\nSEARCH SERIES");
        System.out.println("***********************************");
        
        System.out.println("Enter series id to search: ");
        String searchId = scan.nextLine();
        boolean found = false;
        
        for (SeriesModel series : seriesList) {
            if (series.getSeriesId().equals(searchId)) {
                System.out.println("==================================");
                System.out.println("SERIES ID: " + series.getSeriesId());
                System.out.println("SERIES NAME: " + series.getSeriesName());
                System.out.println("SERIES AGE RESTRICTION: " + series.getSeriesAge());
                System.out.println("SERIES NUMBER OF EPISODES: " + series.getSeriesNumberOfEpisodes());
                System.out.println("==================================");
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("Series with Series Id: " + searchId + " was not found!");         
        }
        
    }
    
    public void updateSeries() {
        
        System.out.println("\nUPDATE SERIES");
        System.out.println("***********************************");
        
        System.out.println("Enter the series id to update: ");
        String updateId = scan.nextLine();
        boolean found = false;
        
        for (SeriesModel series : seriesList) {
            if (series.getSeriesId().equals(updateId)) {
                System.out.print("Enter the series name: ");
                String newName = scan.nextLine();
                
                int newAge = getValidatedAge(); // Call the reusable method
                                    
                // number of episodes 
                System.out.print("Enter the number of episodes: ");
                int newEpisodes = scan.nextInt();
                scan.nextLine(); //consume new line
                    
                // update values
                series.setSeriesName(newName);
                series.setSeriesAge(newAge);
                series.setSeriesNumberOfEpisodes(newEpisodes);
                    
                System.out.println("Series updated successfully!!!");
                found = true;
                break;
            }
        }
 
        if (!found) {
            System.out.println("Series with Series Id: " + updateId + " was not found!");
        }  
    }
    
    public void deleteSeries() {
        
        System.out.println("\nDELETE A SERIES");
        System.out.println("***********************************");
        
        System.out.println("Enter the Series Id to delete: ");
        String deleteId = scan.nextLine();
        
        boolean found = false;

        // Use Iterator for safe removal of elements from the ArrayList
        Iterator<SeriesModel> iterator = seriesList.iterator();
        while (iterator.hasNext()) {
            SeriesModel series = iterator.next();
            if (series.getSeriesId().equals(deleteId)) {
                // Ask for confirmation
                System.out.print("Are you sure you want to delete series " + deleteId + " from the system? Yes (y) to delete: ");
                String confirm = scan.nextLine();

                if (confirm.equalsIgnoreCase("y")) {
                    iterator.remove(); // safe removal
                    System.out.println("----------------------------------");
                    System.out.println("Series with Series Id: " + deleteId + " WAS deleted!");
                    System.out.println("----------------------------------");
                } else {
                    System.out.println("Delete cancelled. Series not removed.");
                }

                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series with Id: " + deleteId + " was not found!");
        }

    }
    
    public void SeriesReport() {
       
        System.out.println("\nPRINT SERIES REPORT - 2025");
        System.out.println("***********************************");

        if (seriesList.isEmpty()) {
            System.out.println("No series available to display.");
        } else {
            int count = 1;
            for (SeriesModel series : seriesList) {
                System.out.println("Series " + count);
                System.out.println("==================================");
                System.out.println("SERIES ID: " + series.getSeriesId());
                System.out.println("SERIES NAME: " + series.getSeriesName());
                System.out.println("SERIES AGE RESTRICTION: " + series.getSeriesAge());
                System.out.println("NUMBER OF EPISODES: " + series.getSeriesNumberOfEpisodes());
                System.out.println("==================================");
                count++;
            }
        }
    }
    
    // ================== LOGIC METHODS FOR UNIT TESTS ==================

    //Find a series by ID
    public SeriesModel findSeriesById(String id) {
        for (SeriesModel series : seriesList) {
            if (series.getSeriesId().equals(id)) {
                return series;
            }
        }
        return null;
    }

    //Update a series by ID
    public boolean updateSeriesById(String id, String newName, int newAge, int newEpisodes) {
        SeriesModel series = findSeriesById(id);
        if (series != null) {
            series.setSeriesName(newName);
            series.setSeriesAge(newAge);
            series.setSeriesNumberOfEpisodes(newEpisodes);
            return true;
        }
        return false;
    }

    //Delete a series by ID
    public boolean deleteSeriesById(String id) {
        return seriesList.removeIf(s -> s.getSeriesId().equals(id));
    }

    public void addSeries(SeriesModel series) {
        seriesList.add(series);
    }

    public ArrayList<SeriesModel> getAllSeries() {
        return seriesList;
    }
    
    //Validate age restriction
    public boolean isValidAgeRestriction(int age) {
        return age >= 2 && age <= 18;
    }

    
    public void ExitSeriesApplication() {
        
        System.out.println("\nExiting Series Application...");
        System.out.println("Thank you for using the system. Goodbye!");
        System.exit(0); // Terminates the program completely
        
    }
}
